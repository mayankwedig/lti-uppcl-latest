import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-requesttrack',
  templateUrl: './requesttrack.component.html',
  styleUrls: ['./requesttrack.component.css']
})
export class RequesttrackComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
