import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-important-links',
  templateUrl: './important-links.component.html',
  styleUrls: ['./important-links.component.css']
})
export class ImportantLinksComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
