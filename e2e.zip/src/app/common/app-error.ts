export class AppError{
    constructor(public orignalError?:any){
        
    }
}